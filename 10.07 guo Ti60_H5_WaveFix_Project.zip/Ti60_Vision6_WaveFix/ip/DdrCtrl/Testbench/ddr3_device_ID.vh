`define sg25E 
