from PIL import Image
from pathlib import Path
import subprocess,json
P=Path(__file__).resolve().parents[1]
im=Image.open(P.parent/'facedetect-fpga/gen_dataset/image0_320_240.pgm').convert('L').resize((160,120),Image.Resampling.NEAREST).crop((0,15,160,105))
v=list(im.getdata());(P/'sim/positive.mem').write_text('\n'.join(f'{x:02x}' for x in v)+'\n');im.save(P/'reports/test_input.png')
golden=[]
for stride,w,h in [(8,160,90),(10,128,72),(12,106,60),(16,80,45)]:
 data=bytes(v[(y*stride//8)*160+x*stride//8] for y in range(h) for x in range(w))
 fn=P/f'sim/scale{stride}.raw';fn.write_bytes(data)
 r=subprocess.run([str(P/'tools/haar_reference.exe'),str(fn),str(w),str(h),'2'],capture_output=True,text=True,check=True)
 for row in r.stdout.strip().splitlines():
  x,y,_,_=map(int,row.split(','));golden.append([x*stride+4,y*stride+4,24*stride])
(P/'sim/expected.mem').write_text('\n'.join(f'{x|(y<<11)|(s<<21):08x}' for x,y,s in golden)+'\n')
(P/'sim/expected_count.vh').write_text(f'`define EXPECTED_COUNT {len(golden)}\n')
(P/'reports/golden_detections.json').write_text(json.dumps(golden,indent=2))
assert len(golden)>0
print('Expected detections',len(golden),golden)
