# Development note

`configure_project.py` and `configure_xml.py` record initial scaffolding and should not be rerun on this already configured project. `add_diagnostics.py` records a one-time patch, not an idempotent build step. Use run_tests.ps1 and build.ps1 for normal work.

The recorded manifest is evidence of a verified build. Running record_verified_build.py is appropriate only after reviewing all new RTL, completed current tests, and the latest resource/timing reports; it is not a substitute for those checks.
