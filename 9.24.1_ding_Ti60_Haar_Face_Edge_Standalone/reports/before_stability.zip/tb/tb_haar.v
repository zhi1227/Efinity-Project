`timescale 1ns/1ps
`include "sim/expected_count.vh"
module tb_haar;
 reg clk=0;always #5 clk=~clk;
 reg rst_n=0,load_we=0,start=0;reg [13:0] addr=0;reg [7:0] pixel=0;
 wire busy,done,dv;wire [10:0] x;wire [9:0] y,s;wire [31:0] cycles;wire [15:0] raw;
 haar_engine dut(.clk(clk),.rst_n(rst_n),.load_we(load_we),.load_addr(addr),.load_pixel(pixel),.start(start),.busy(busy),.done(done),.det_valid(dv),.det_x(x),.det_y(y),.det_size(s),.cycles(cycles),.raw_count(raw),.debug_addr(14'd0));
 reg [7:0] im[0:14399];reg [31:0] exp[0:`EXPECTED_COUNT-1];
 integer i,count=0,phase=0,total=0;
 initial begin
  $readmemh("sim/positive.mem",im);$readmemh("sim/expected.mem",exp);
  repeat(5)@(negedge clk);rst_n=1;
  for(phase=0;phase<2;phase=phase+1)begin
   count=0;
   for(i=0;i<14400;i=i+1)begin @(negedge clk);load_we=1;addr=i;pixel=phase==0?im[i]:8'd128;end
   @(negedge clk);load_we=0;start=1;@(negedge clk);start=0;
   wait(done);@(negedge clk);
   if(phase==0 && count!=`EXPECTED_COUNT)$fatal(1,"FAIL count %d",count);
   if(phase==1 && count!=0)$fatal(1,"FAIL stale/blank %d",count);
   $display("PASS frame %0d detections=%0d cycles=%0d",phase,count,cycles);
  end
  $display("PASS tb_haar positive and subsequent blank frame, all boxes exact");$finish;
 end
 always @(negedge clk)begin
  if(dv)begin
   if(phase==1)$fatal(1,"FAIL blank detection");
   if(count>=`EXPECTED_COUNT)$fatal(1,"FAIL extra detection");
   if({1'b0,s,y,x}!==exp[count])$fatal(1,"FAIL box %0d actual=%h expected=%h",count,{1'b0,s,y,x},exp[count]);
   count=count+1;
  end
  total=total+1;if(total>70000000)$fatal(1,"FAIL timeout state=%d",dut.state);
 end
endmodule
