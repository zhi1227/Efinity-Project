from pathlib import Path
import subprocess,re
P=Path(r'D:\yilingsi_fpga\Efinity_Project\2026.9.24\Ti60_Haar_Face_Edge_Standalone')
subprocess.run([r'C:\Users\Lenovo\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe',str(P/'tools/generate_test.py')],check=True)
v=[int(a,16)*17 for a in (P/'model/selftest.mem').read_text().split()]
count=0
for stride in [8,9,10,11,12,14,16]:
 w,h=1280//stride,720//stride
 f=P/f'sim/self_scale{stride}.raw';f.write_bytes(bytes(v[(y*stride//8)*160+x*stride//8] for y in range(h) for x in range(w)))
 r=subprocess.run([str(P/'tools/haar_reference.exe'),str(f),str(w),str(h),'2'],check=True,capture_output=True,text=True)
 n=len(r.stdout.splitlines());count+=n;print('Self-test scale',stride,'raw',n)
f=P/'src/haar/haar_face_video.v'
expected=int(re.search(r'SELF_EXPECTED=(\d+)',f.read_text())[1])
assert count==expected, (count,expected)
print('Independent reference self-test count',count)
