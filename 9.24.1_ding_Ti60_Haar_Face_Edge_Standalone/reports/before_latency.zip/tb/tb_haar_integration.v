`timescale 1ns/1ps
module tb_haar_integration;
 reg clk=0;always #5 clk=~clk;
 reg rst_n=0;reg[23:0]rgb=0;reg de=0,vs=0,hs=0;
 wire[23:0]out;wire od,ov,oh,overflow;
 haar_face_video #(.DIAGNOSTICS(0),.SELF_TEST(0),.HOLD_FRAMES(4)) dut(clk,rst_n,rgb,de,vs,hs,3'd1,12'd40,12'd80,out,od,ov,oh,overflow);
 reg[7:0]im[0:14399];integer row,col,f,idx,i;reg[7:0]v;
 integer saw_face=0,saw_clear=0,published=0;reg[3:0]last_count=0;reg[335:0]last_boxes=0;reg prev_fs=0;
 reg[7:0]r8,g8,b8;reg[15:0]lum;
 always @(posedge clk)if(rst_n)begin
  if(dut.start)begin
   for(i=0;i<14400;i=i+1)begin
    v=dut.captured_id==1?im[i]:8'd128;
    r8={v[7:3],v[7:5]};g8={v[7:2],v[7:6]};b8=r8;lum=77*r8+150*g8+29*b8;
    if(dut.core.frame_mem[i]!==lum[15:8])$fatal(1,"FAIL snapshot pixel %0d frame=%0d got=%0d expected=%0d",i,dut.captured_id,dut.core.frame_mem[i],lum[15:8]);
   end
   $display("PASS captured snapshot frame_id=%0d",dut.captured_id);
  end
  prev_fs=dut.display_fs;
  #1;
  if(dut.display_count!=last_count||dut.display_boxes!=last_boxes)begin
    if(!prev_fs)$fatal(1,"FAIL boxes changed mid-frame");
    if(dut.display_count>0)begin saw_face=1;$display("PASS positive frame published faces=%0d raw=%0d",dut.display_count,dut.last_raw);end
    if(saw_face&&dut.display_count==0)begin saw_clear=1;$display("PASS blank frame clears faces");end
  end
  last_count=dut.display_count;last_boxes=dut.display_boxes;
 end
 initial begin
  $readmemh("sim/positive.mem",im);repeat(5)@(negedge clk);rst_n=1;
  for(f=0;f<18;f=f+1)begin
   for(row=0;row<750;row=row+1)for(col=0;col<1650;col=col+1)begin
    @(negedge clk);vs=row>=5;hs=col>=40;de=row>=25&&row<745&&col>=200&&col<1480;
    if(de)begin idx=((row-25)/8)*160+(col-200)/8;rgb=f<4?{im[idx],im[idx],im[idx]}:24'h808080;end
    else rgb=0;
   end
  end
  if(!saw_face||!saw_clear||overflow)$fatal(1,"FAIL integration face=%d clear=%d overflow=%b",saw_face,saw_clear,overflow);
  $display("PASS end-to-end 720p capture -> Haar -> frame-atomic boxes -> blank clear");$finish;
 end
endmodule
